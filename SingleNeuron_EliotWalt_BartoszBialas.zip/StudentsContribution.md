# Students contribution

The miniproject consisting of two main parts,  we naturally decided to split the work this way. Bartosz Bialas was assigned to Part1: "Exploration of Hodgkin Huxley neurons" and Eliot Walt to Part 2: "From HH to AdEx". 

## Code

- Bartosz Bialas, having other assignments, was only able to produce code for part 1.1, leaving parts 1.2 and 1.3 empty.
- Eliot Walt produced all the code for part 2, relying on the `adaptive` function implemented in part 1.1 by Bartosz Bialas.

## Report

- Bartosz Bialas did not contribute to the report. His parts, including the introduction and conclusion were left empty. This is why his name is in parenthesis on the report.
- Eliot Walt wrote the rest of the report.

## Collaboration

- Part 2 relying on the `adaptive` function in part 1, Eliot Walt had to wait and insist on Bartosz Bialas' implementation.
- Eliot Walt tried to have meetings with Bartosz Bialas both in person and on zoom. Bartosz Bialas always declined or canceled last minute.
- Bartosz Bialas informed Eliot Walt at 9:52pm on June 6 that he could not finish the project due to other assignments taking too much time. **He acknowledged that the grading should be asymmetric**. 

